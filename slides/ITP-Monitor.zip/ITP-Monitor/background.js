// chrome.runtime.onInstalled.addListener(() => {
//   chrome.action.setBadgeText({
//     text: "OFF",
//   });
// });

// chrome.action.onClicked.addListener(async (tab) => {
//   // if (tab.url.startsWith(extensions) || tab.url.startsWith(webstore)) {
//   //   // Retrieve the action badge to check if the extension is 'ON' or 'OFF'
//   //   const prevState = await chrome.action.getBadgeText({ tabId: tab.id });
//   //   // Next state will always be the opposite
//   //   const nextState = prevState === 'ON' ? 'OFF' : 'ON'

//   //   // Set the action badge to the next state
//   //   await chrome.action.setBadgeText({
//   //     tabId: tab.id,
//   //     text: nextState,
//   //   });
//   // }
//   // const res=await fetch("http://172.16.128.17/".concat(tab.id.toString()));
//   console.log("tab has changed")
// });

chrome.windows.onFocusChanged.addListener(async (windowID) => {
  if (windowID == chrome.windows.WINDOW_ID_NONE){
    console.log("Chrome lost focused");
    applicationChaneged("Another application might be opned");
  }
  if (windowID !== chrome.windows.WINDOW_ID_NONE){
    console.log("Tab change detected");
    applicationChaneged("Tab change detected");
  }
});

function applicationChaneged(comment) {
  chrome.storage.local.get('trackUser', function(data) {
    if (data.trackUser) {
      const userDetails = data.trackUser;
      fetch('http://192.168.50.82:8000/track/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          name: userDetails.name,
          roll: userDetails.roll,
          email: userDetails.email,
          url: " ",
          title: " ",
          comment: comment
        })
      })
      .then(response => response.json())
      .then(data => {
        console.log('Success:', data);
      })
      .catch((error) => {
        console.error('Error:', error);
      });
    }
  });
}

let activeTabId, lastUrl, lastTitle;

function getTabInfo(tabId, comment) {
  chrome.tabs.get(tabId, function(tab) {
    var url = " ";
    try {
      url = tab.url;
    }
    catch(err) {
      console.error('Error:', err);
    }
    
    var title = " ";
    try {
      title = tab.title;
    }
    catch(err) {
      console.error('Error:', err);
    }

    chrome.storage.local.get('trackUser', function(data) {
      if (data.trackUser) {
        const userDetails = data.trackUser;
        fetch('http://192.168.50.82:8000/track/', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            name: userDetails.name,
            roll: userDetails.roll,
            email: userDetails.email,
            url: url,
            title: title,
            comment: comment
          })
        })
        .then(response => response.json())
        .then(data => {
          console.log('Success:', data);
        })
        .catch((error) => {
          console.error('Error:', error);
        });
      }
    });
    
    // if (tab.url.startsWith('https://prutor.cse.iith.ac.in/') == false) {
    //   console.log('Accessed ', tab.url);
    // }
  });
}

chrome.tabs.onActivated.addListener(function(activeInfo) {
  console.log("On tab activate");
  // const res=fetch("http://prutor.cse.iith.ac.in:8000/".concat(activeInfo.tabId.toString()));
  getTabInfo(activeTabId = activeInfo.tabId, "Tab change detected");
});

chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
  if(changeInfo.status === 'complete' && tab.active) {
    console.log("On tab update");
    getTabInfo(activeTabId=tabId, "Tab data updated");
  }
});